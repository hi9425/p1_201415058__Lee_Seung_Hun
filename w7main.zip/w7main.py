﻿
for i in range(10):
    print " "*(10-i)+"*"*(i*2-1)
raw_input("triangle 201415058 Lee Seung Hun")
